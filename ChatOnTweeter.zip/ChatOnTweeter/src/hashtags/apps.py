from django.apps import AppConfig


class HashtagsConfig(AppConfig):
    name = 'hashtags'
