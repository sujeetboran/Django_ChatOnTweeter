from django.dispatch import Signal

parsed_hashtags = Signal(providing_args=['hashtag_list'])