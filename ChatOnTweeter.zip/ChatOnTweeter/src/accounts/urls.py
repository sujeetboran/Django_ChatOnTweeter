from django.urls import path, include
from django.views.generic.base import RedirectView

from .views import (
    UserDetailView,
    UserFollowView
    )

urlpatterns = [
    path('(?P<username>[w.@+-]+)/', UserDetailView.as_view(), name='detail'), 
    path('(?P<username>[w.@+-]+)/follow/', UserFollowView.as_view(), name='follow'),
]

