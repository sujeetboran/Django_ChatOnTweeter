from django.urls import path
from django.views.generic.base import RedirectView
from .views import (
    LikeToggleAPIView,
    RetweetAPIView,
    TweetCreateAPIView,
    TweetListAPIView,
    TweetDetailAPIView,
    )
urlpatterns = [
    path('', TweetListAPIView.as_view(), name='list'),
    path('create/', TweetCreateAPIView.as_view(), name='create'), 
    path('(?P<pk>d+)/', TweetDetailAPIView.as_view(), name='detail'),
    path('(?P<pk>d+)/like/', LikeToggleAPIView.as_view(), name='like-toggle'),
    path('(?P<pk>d+)/retweet/', RetweetAPIView.as_view(), name='retweet'),
]

